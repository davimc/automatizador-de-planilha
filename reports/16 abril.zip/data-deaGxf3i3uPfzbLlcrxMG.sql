INSERT INTO card_vaccine (id,date,anima_id,vaccine_id)
VALUES (1,"2022-10-10",12,9);
INSERT INTO card_vaccine (id,date,anima_id,vaccine_id)
VALUES (2,"2023-07-29",7,9);
INSERT INTO card_vaccine (id,date,anima_id,vaccine_id)
VALUES (3,"2023-05-15",8,16);
INSERT INTO card_vaccine (id,date,anima_id,vaccine_id)
VALUES (4,"2023-07-12",14,5);
INSERT INTO card_vaccine (id,date,anima_id,vaccine_id)
VALUES (5,"2022-09-08",19,14);
INSERT INTO card_vaccine (id,date,anima_id,vaccine_id)
VALUES (6,"2023-06-29",5,7);
INSERT INTO card_vaccine (id,date,anima_id,vaccine_id)
VALUES (7,"2022-02-13",18,19);
INSERT INTO card_vaccine (id,date,anima_id,vaccine_id)
VALUES (8,"2023-03-26",10,17);
INSERT INTO card_vaccine (id,date,anima_id,vaccine_id)
VALUES (9,"2022-09-29",23,13);
INSERT INTO card_vaccine (id,date,anima_id,vaccine_id)
VALUES (10,"2022-08-19",14,7);
INSERT INTO card_vaccine (id,date,anima_id,vaccine_id)
VALUES (11,"2022-04-03",3,4);
INSERT INTO card_vaccine (id,date,anima_id,vaccine_id)
VALUES (12,"2022-12-16",23,6);
INSERT INTO card_vaccine (id,date,anima_id,vaccine_id)
VALUES (13,"2024-01-29",12,22);
INSERT INTO card_vaccine (id,date,anima_id,vaccine_id)
VALUES (14,"2023-07-12",22,8);
INSERT INTO card_vaccine (id,date,anima_id,vaccine_id)
VALUES (15,"2022-10-02",22,2);
INSERT INTO card_vaccine (id,date,anima_id,vaccine_id)
VALUES (16,"2022-08-10",22,4);
INSERT INTO card_vaccine (id,date,anima_id,vaccine_id)
VALUES (17,"2022-06-17",24,7);
INSERT INTO card_vaccine (id,date,anima_id,vaccine_id)
VALUES (18,"2023-03-11",21,13);
INSERT INTO card_vaccine (id,date,anima_id,vaccine_id)
VALUES (19,"2023-01-09",14,21);
INSERT INTO card_vaccine (id,date,anima_id,vaccine_id)
VALUES (20,"2022-09-11",15,7);
INSERT INTO card_vaccine (id,date,anima_id,vaccine_id)
VALUES (21,"2022-02-15",6,15);
INSERT INTO card_vaccine (id,date,anima_id,vaccine_id)
VALUES (22,"2022-04-27",19,12);
INSERT INTO card_vaccine (id,date,anima_id,vaccine_id)
VALUES (23,"2023-03-02",3,13);
INSERT INTO card_vaccine (id,date,anima_id,vaccine_id)
VALUES (24,"2023-04-28",20,4);
INSERT INTO card_vaccine (id,date,anima_id,vaccine_id)
VALUES (25,"2023-08-07",15,18);
